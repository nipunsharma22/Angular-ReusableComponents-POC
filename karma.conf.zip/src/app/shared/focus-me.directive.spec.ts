import { FocusMeDirective } from './focus-me.directive';

describe('FocusMeDirective', () => {
  it('should create an instance', () => {
    const directive = new FocusMeDirective();
    expect(directive).toBeTruthy();
  });
});
