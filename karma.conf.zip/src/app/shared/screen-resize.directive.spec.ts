import { ScreenResizeDirective } from './screen-resize.directive';

describe('ScreenResizeDirective', () => {
  it('should create an instance', () => {
    //const directive = new ScreenResizeDirective();
    //expect(directive).toBeTruthy();
  });
});
