import { Directive } from '@angular/core';

@Directive({
  selector: '[appFocusMe]'
})
export class FocusMeDirective {

  constructor() { }

}
