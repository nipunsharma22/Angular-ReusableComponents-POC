import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-accordianform',
  templateUrl: './accordianform.component.html',
  styleUrls: ['./accordianform.component.scss']
})
export class AccordianformComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}


