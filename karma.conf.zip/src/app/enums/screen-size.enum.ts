export enum SCREEN_SIZE {
  XS,
  SM,
  MD,
  LG
}

