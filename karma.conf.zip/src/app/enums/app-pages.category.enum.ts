export enum APP_PAGES_CATEGORY {
  WorkspaceManagement,
  Transport,
  System,
  }