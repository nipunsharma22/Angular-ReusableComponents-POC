export enum APP_PAGES_ACTIONS {
    ADD = "add",
    DELETE = "delete",
    SAVE_DRAFT = "save-draft",
    SAVE_PUBLISH = "save-publish",
    PUBLISH = "publish",
    EDIT = "edit",
    CHECK_DUPLICATE = "check-duplicate",
    GET_DETAILS = "get-details"
}
